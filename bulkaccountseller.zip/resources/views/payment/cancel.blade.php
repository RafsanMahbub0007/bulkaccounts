<h1>Payment Failed ❌</h1>
<p>Your payment was cancelled or expired.</p>
<a href="{{ route('checkout') }}">Try Again</a>
