<?php

namespace App\Livewire;

use Livewire\Component;

class Offer extends Component
{
    public function render()
    {
        return view('livewire.offer');
    }
}
