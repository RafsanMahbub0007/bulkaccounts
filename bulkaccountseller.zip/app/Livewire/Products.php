<?php

namespace App\Livewire;

use App\Models\Category;
use App\Models\Product;
use App\Models\Setting;
use Livewire\Attributes\Layout;
use Livewire\Component;
use Livewire\WithPagination;

class Products extends Component
{
    use WithPagination;

    public $search = '';
    public $category = [];
    public $sortDirection = 'asc';

    #[Layout('layouts.app')]
    public function render()
    {
        $categories = Category::all();
        $system = Setting::find(1);
        $products = Product::query()
            ->when($this->search, function ($query) {
                $query->where('name', 'like', '%' . $this->search . '%')
                    ->orWhere('description', 'like', '%' . $this->search . '%');
            })
            ->when(!empty($this->category), function ($query) {
                $query->whereIn('category_id', $this->category);
            })
            ->orderBy('selling_price', $this->sortDirection)
            ->paginate(12);

        return view('livewire.products', compact('products', 'categories', 'system'));
    }
}
